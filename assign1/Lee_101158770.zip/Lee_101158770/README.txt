Jalena Lee 
Student Number: 101158770

Design Decisions 
- I choose to design the code as efficient as possible (using what little javascript I know) 
- Divs played a major role in grouping my items in the menu together so that I could access the element's ids to compute the calculations and contribute to the order summary 
- visual design elements were centered around a great user experience and has been optimized for resizing 
- leveraged divs to make it easier to separate my elements and it was easier to control smaller portions of the code at a time vs having one BIG div and putting everything inside 

Instructions 
- open the order.html file in a browser 
- select a restaurant from the drop down menu and you should see that restaurants menu, categories, min order, and delivery fee
- you can order from the restaurant by adding items to your cart or removing items 
- enjoy 😊


4, 11, 18

0 = name 
, 4 = price  6 = quantity 

childDiv = menu items + price + input field 